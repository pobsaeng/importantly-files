package com.multibank.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.multibank.domain.entity.Items;

@Repository
public interface ItemsRepository extends JpaRepository<Items, Integer>{
	@Transactional
	@Query(value = "SELECT tms FROM Items tms WHERE tms.user_item_id=:user_item_id")
	List<Items> findItemByUserItemId(@Param("user_item_id") Integer user_item_id);
	
	@Transactional
	@Modifying
	@Query(value = "UPDATE items SET item_name = ? WHERE user_item_id = ?", nativeQuery = true)
	int updateItemByUserItemId(String item_name, Integer user_item_id);

//	@Transactional
//	@Modifying
//	@Query("update Items i set i.item_name =:item_name where i.item_id =:item_id")
//	void updateItems(@Param("item_name") String item_name, @Param("item_id") Integer item_id);

	@Transactional
	@Modifying
	@Query(value = "DELETE FROM items WHERE user_item_id = ?", nativeQuery = true)
	int deleteByUserItemId(Integer user_item_id);

}
