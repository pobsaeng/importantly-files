package com.multibank.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.multibank.domain.entity.UserItems;

@Repository
public interface UserItemsRepository extends JpaRepository<UserItems, Integer> {
	@Query(value = "SELECT utms FROM UserItems utms WHERE utms.user_id=:user_id")
	UserItems findUserById(@Param("user_id") Integer user_id);
	
	@Transactional
	@Modifying
	@Query(value = "DELETE FROM user_items WHERE user_id = ?", nativeQuery = true)
	int deleteByUserId(Integer user_id);
}
