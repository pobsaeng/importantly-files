package com.multibank.domain.entity;

public class ListItems {
	private Integer item_id;
	private String item_name;
	private String user_item_id;
	private String type;
	private String icon;
	private String name;
	private String router;

	public Integer getItem_id() {
		return item_id;
	}

	public void setItem_id(Integer item_id) {
		this.item_id = item_id;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public String getUser_item_id() {
		return user_item_id;
	}

	public void setUser_item_id(String user_item_id) {
		this.user_item_id = user_item_id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRouter() {
		return router;
	}

	public void setRouter(String router) {
		this.router = router;
	}

	@Override
	public String toString() {
		return "ListItems [item_id=" + item_id + ", item_name=" + item_name + ", user_item_id=" + user_item_id
				+ ", type=" + type + ", icon=" + icon + ", name=" + name + ", router=" + router + "]";
	}

}
