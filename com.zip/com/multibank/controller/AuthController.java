package com.multibank.controller;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.multibank.baseconfig.JwtTokenProvider;
import com.multibank.domain.entity.Items;
import com.multibank.domain.entity.ListItems;
import com.multibank.domain.entity.Role;
import com.multibank.domain.entity.RoleName;
import com.multibank.domain.entity.User;
import com.multibank.domain.entity.UserItems;
import com.multibank.exception.APIException;
import com.multibank.exception.AppException;
import com.multibank.exception.ResourceNotFoundException;
import com.multibank.model.json.request.LoginRequest;
import com.multibank.model.json.request.SignUpRequest;
import com.multibank.model.json.response.JwtAuthenResponse;
import com.multibank.repository.ItemsRepository;
import com.multibank.repository.RoleRepository;
import com.multibank.repository.UserItemsRepository;
import com.multibank.repository.UserRepository;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	UserItemsRepository userItemsRepository;
	
	@Autowired
	ItemsRepository itemsRepository;

	@Autowired
	RoleRepository roleRepository;

	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	JwtTokenProvider tokenProvider;
	
	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@RequestBody LoginRequest loginRequest, HttpServletRequest request) throws APIException{
		System.out.println("--------AuthController[signin]------------");
		if(loginRequest.getUsername().equals("")) {
			throw new APIException(
					"Usernae is require!",
					HttpServletResponse.SC_UNAUTHORIZED,
					HttpStatus.BAD_REQUEST.value(),
					request.getServletPath(),
					new Timestamp(System.currentTimeMillis())
					);
			
		}else if(loginRequest.getPassword().equals("")) {
			throw new APIException(
					"Password is require!",
					HttpServletResponse.SC_UNAUTHORIZED,
					HttpStatus.BAD_REQUEST.value(),
					request.getServletPath(),
					new Timestamp(System.currentTimeMillis())
					);
		}
		Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));
		SecurityContextHolder.getContext().setAuthentication(authentication);

		String jwt = tokenProvider.generateToken(authentication);
		System.out.println("[jwt: " + tokenProvider.getUserIdFromJWT(jwt) + "]");
		return ResponseEntity.ok(new JwtAuthenResponse(jwt));
	}
	
	@PostMapping("/signup")
	public ResponseEntity<?> registerUser(@RequestBody SignUpRequest signUpRequest) {
		System.out.println("+--------signup--------+");

		User user = new User();
		user.setUser_id(signUpRequest.getUser_id());
		user.setFullname(signUpRequest.getFullname());
		user.setEmail(signUpRequest.getEmail());
		user.setUsername(signUpRequest.getUsername());
		user.setPassword(passwordEncoder.encode(signUpRequest.getPassword()));
		user.setUpdated_date(null);
		user.setCreated_date(null);
		Role userRole = roleRepository.findByName(RoleName.ROLE_USER).orElseThrow(() -> new AppException("User Role not set."));
		user.setRoles(Collections.singleton(userRole));
		User sUser = userRepository.save(user);
		
		if(sUser != null) {
			//insert UserItems
			UserItems userItems = new UserItems();
			userItems.setUser_id(sUser.getUser_id());
			if(!userItemsRepository.existsById(sUser.getUser_id())) {
				UserItems uitems = userItemsRepository.save(userItems);
				//insert Items
				List<ListItems> listItems = signUpRequest.getItems();
				for (ListItems ls : listItems) {
					Items items = new Items();
					items.setUser_item_id(uitems.getUser_item_id());
					items.setItem_name(ls.getItem_name());
					itemsRepository.save(items);
				}
			}else {
				throw new ResourceNotFoundException("Cannot insert UserItems with exists id : " + signUpRequest.getUser_id(), null, null);
			}
		}else {
			throw new ResourceNotFoundException("Cannot insert User with id : " + signUpRequest.getUser_id(), null, null);
		}

		return ResponseEntity.ok(signUpRequest);
	}
}
