package com.multibank.controller;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.multibank.domain.entity.Items;
import com.multibank.domain.entity.ListItems;
import com.multibank.domain.entity.User;
import com.multibank.domain.entity.UserItems;
import com.multibank.exception.ResourceNotFoundException;
import com.multibank.model.json.request.ResetPassRequest;
import com.multibank.model.json.request.SignUpRequest;
import com.multibank.repository.ItemsRepository;
import com.multibank.repository.RoleRepository;
import com.multibank.repository.UserItemsRepository;
import com.multibank.repository.UserRepository;


@RestController
@RequestMapping("/api/user")
public class UserController {
	@Autowired
	UserRepository userRepository;
	@Autowired
	UserItemsRepository userItemsRepository;
	@Autowired
	ItemsRepository itemsRepository;
	@Autowired
	RoleRepository roleRepository;
	
	@GetMapping("/findall")
    public ResponseEntity<?> getFindAll() {
		List<User> users = userRepository.findAllUsers();
		
		Map<String, Object> baseMap = new HashMap<>();
		Map<String, Object> mobj = new HashMap<>();
		Map<String, Object> map = null;
		List<Map<String, Object>> lsItems = null;

		for (int i = 0; i < users.size(); i++) {
			lsItems = new ArrayList<>();

			map = new TreeMap<>();
			map.put("data", users.get(i));

			UserItems userItems = userItemsRepository.findUserById(users.get(i).getUser_id());
			try {
				List<Items> listItems = itemsRepository.findItemByUserItemId(userItems.getUser_item_id());
				map.put("menu", listItems);
				
			} catch (Exception e) {
				List<Items> listItems = new ArrayList();
				map.put("menu", listItems);
			}
			
			mobj.put("user" + i, map);
			lsItems.add(mobj);
		}
		baseMap.put("result", lsItems);
    	
		return new ResponseEntity(baseMap, HttpStatus.OK);
    }

	@PutMapping("/update")
    public ResponseEntity<?> updateAnswer(@RequestBody SignUpRequest signUpRequest) {
		System.out.println(signUpRequest);
		
        if(!userRepository.existsById(signUpRequest.getUser_id())) {
            throw new ResourceNotFoundException("User not found with id " + signUpRequest.getUser_id(), null, null);
        }
        User user = userRepository.findById(signUpRequest.getUser_id())
        .map(u -> {
        	u.setUser_id(signUpRequest.getUser_id());
        	u.setFullname(signUpRequest.getFullname());
        	u.setEmail(signUpRequest.getEmail());
            return userRepository.save(u);
        }).orElseThrow(() -> new ResourceNotFoundException("User not found with id " + signUpRequest.getUser_id(), null, null));
        
        UserItems uitems = userItemsRepository.findUserById(signUpRequest.getUser_id());             
        if(uitems != null) {
        	List<Items> lsItems = itemsRepository.findItemByUserItemId(uitems.getUser_item_id());
        	//remove all items of this user
        	if(lsItems != null) {
        		for(Items itm : lsItems) {
            		itemsRepository.deleteById(itm.getItem_id());
            	}
        		//insert new items of this user
        		saveItems(signUpRequest.getItems(), uitems.getUser_item_id());	
        	}else {
        		//insert new items of this user
        		saveItems(signUpRequest.getItems(), uitems.getUser_item_id());	
        	}

        }
        return ResponseEntity.ok(user);
    }
	private void saveItems(List<ListItems> listItems, Integer user_item_id){
		for (ListItems ls : listItems) {
			Items items = new Items();
			items.setUser_item_id(user_item_id);
			items.setItem_name(ls.getItem_name());
			itemsRepository.save(items);
		}
	}
	@GetMapping("/delete/{user_id}")
    public ResponseEntity<?> deleteUser(@PathVariable("user_id") Integer user_id) throws Exception {
		return userRepository.findById(user_id)
                .map(user -> {
                	UserItems uItem = userItemsRepository.findUserById(user.getUser_id());
                	try {
                		if(uItem != null) {
                        	List<Items> lsItems = itemsRepository.findItemByUserItemId(uItem.getUser_item_id());
                        	
                        	for(Items item : lsItems) {
                        		itemsRepository.deleteById(item.getItem_id());
                        	}
                        	userItemsRepository.deleteById(uItem.getUser_item_id());
                    	}
                    	userRepository.deleteById(user.getUser_id());
                    	
					} catch (Exception e) {
						return ResponseEntity.notFound().build();
					}
                    return ResponseEntity.ok().build();
                }).orElse(ResponseEntity.notFound().build());
	}
	@GetMapping("/finbyuser/{user_id}")
    public ResponseEntity<?> getFinByUser(@PathVariable("user_id") Integer user_id) {
		System.out.println("user_id: " + user_id);
		Map<String, Object> mResult = new HashMap<>();
		Map<String, Object> map = new HashMap<>();
		
    	Optional<User> users = userRepository.findById(user_id);
    	UserItems userItems = userItemsRepository.findUserById(users.get().getUser_id());
    	List<Items> listItems = itemsRepository.findItemByUserItemId(userItems.getUser_item_id());
    	map.put("users", users);
    	map.put("Items", listItems);
    	
    	mResult.put("results", map);
		return new ResponseEntity(mResult, HttpStatus.OK);
    }
	@PutMapping("/resetpass")
    public ResponseEntity<?> resetPassword(@RequestBody ResetPassRequest resetPassRequest){
		User user = userRepository.findById(resetPassRequest.getUser_id())
		        .map(u -> {
		        	u.setPassword(resetPassRequest.getPassword());
		            return userRepository.save(u);
		        }).orElseThrow(() -> new ResourceNotFoundException("User not found with id " + resetPassRequest.getUser_id(), null, null));

		return new ResponseEntity(user, HttpStatus.OK);
	}
    @PostMapping("currentuser")
    public ResponseEntity<?> getCurrentUser() {
    	System.out.println("---getCurrentUser---");
//    	UserPrincipal user = (UserPrincipal)SecurityContextHolder.getContext().getAuthentication().getPrincipal();         

    	  String username = "";
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();
		} else {
			username = principal.toString();
		}

    	return new ResponseEntity(username, HttpStatus.OK);
    }
}